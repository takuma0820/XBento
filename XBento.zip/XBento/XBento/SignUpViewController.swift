//
//  SignUpViewController.swift
//  XBento
//
//  Created by TAKUMA NAKAMURA on 2018/05/01.
//  Copyright © 2018年 TAKUMA NAKAMURA. All rights reserved.
//

import UIKit
import NCMB

class SignUpViewController: UIViewController,UITextFieldDelegate {
    
    @IBOutlet var userIdTextField: UITextField!
    @IBOutlet var emailTextField: UITextField!
    @IBOutlet var passwordTextField: UITextField!
    @IBOutlet var confirmTextField: UITextField!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        userIdTextField.delegate = self
        emailTextField.delegate = self
        passwordTextField.delegate = self
        confirmTextField.delegate = self
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
    @IBAction func signUp(){
        
             print(userIdTextField.text!, passwordTextField.text!)
        let user = NCMBUser()
        // IDの字数制限
        if (userIdTextField.text?.characters.count)! < 4{
            print("文字数が足りません")
            return
        }
        
        user.userName = userIdTextField.text!
        user.mailAddress = emailTextField.text!
        
        // パスワードの一致確認
        if passwordTextField.text == confirmTextField.text{
            //user.userName = userIdTextField.text!
            user.password  = passwordTextField.text!
        }else{
            print("パスワードの不一致")
        }
        user.signUpInBackground { (error) in
            if error != nil {
                //エラーがあった場合
                print(error)
            } else{
            
                //登録成功
                let storyboard = UIStoryboard(name:"Main", bundle: Bundle.main)
                let rootViewController = storyboard.instantiateViewController(withIdentifier: "RootTabBarController")
                UIApplication.shared.keyWindow?.rootViewController = rootViewController
                
                //ログイン状態の保持
                let ud = UserDefaults.standard
                ud.set(true, forKey: "isLogin")
                ud.synchronize()
            }
            
        }
    }
    
    
}
