//
//  AppDelegate.swift
//  XBento
//
//  Created by TAKUMA NAKAMURA on 2018/04/24.
//  Copyright © 2018年 TAKUMA NAKAMURA. All rights reserved.
//

import UIKit
import NCMB
import GoogleMaps
import GooglePlaces

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {
    
    var window: UIWindow?
    
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplicationLaunchOptionsKey: Any]?) -> Bool {
        
        //DBとの接続のコード
        let applicationKey = "de7d69793fa1e46df5111f0f2d40e464424a4a9aa5b33fdb93e192041fdba114"
        let cliantKey = "1634eda6862d3ae4890dde3aa04766580bd05ea2c409b23dea418538b8a94a34"
        NCMB.setApplicationKey(applicationKey, clientKey: cliantKey)
        
        //ここ
        //Googlemap
        let GoogleMapsAPIKey = "AIzaSyBlwP-3YgX5XT8_AbT0zTOnieAr7ZA67YY"
        let GooglePlacesAPIKey = "AIzaSyBfmpjZR096dDM0eVMOaKwHmfqaHyUG9RE"
        GMSServices.provideAPIKey(GoogleMapsAPIKey)
        GMSPlacesClient.provideAPIKey(GooglePlacesAPIKey)
        
        
        //storyboardの切り替え
        let ud = UserDefaults.standard
        let isLogin = ud.bool(forKey: "isLogin")
        
        if isLogin == true{
            //ログイン中だったら
            self.window = UIWindow(frame: UIScreen.main.bounds)//iPhoneのサイズに合わせてウィンドウを生成
            let storyboard = UIStoryboard(name:"Main", bundle: Bundle.main)//ストーリーボードを取得
            let rootViewController = storyboard.instantiateViewController(withIdentifier: "RootTabBarController")
            self.window?.rootViewController = rootViewController
            self.window?.backgroundColor = UIColor.white
            self.window?.makeKeyAndVisible()
        } else {
              //ログインしてなかったら
            
            self.window = UIWindow(frame: UIScreen.main.bounds)
            let storyboard = UIStoryboard(name:"SiginIn", bundle: Bundle.main)
            let rootViewController = storyboard.instantiateViewController(withIdentifier: "RootNavigationController")
            self.window?.rootViewController = rootViewController
            self.window?.backgroundColor = UIColor.white
            self.window?.makeKeyAndVisible()
 
        }
        
        return true
    }
    
    func applicationWillResignActive(_ application: UIApplication) {
        // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
        // Use this method to pause ongoing tasks, disable timers, and invalidate graphics rendering callbacks. Games should use this method to pause the game.
    }
    
    func applicationDidEnterBackground(_ application: UIApplication) {
        // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
        // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
    }
    
    func applicationWillEnterForeground(_ application: UIApplication) {
        // Called as part of the transition from the background to the active state; here you can undo many of the changes made on entering the background.
    }
    
    func applicationDidBecomeActive(_ application: UIApplication) {
        // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
    }
    
    func applicationWillTerminate(_ application: UIApplication) {
        // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
    }
    
    
}

